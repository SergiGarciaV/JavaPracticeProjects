public class CorredInsensatos {

	public static void main(String[]args){

	System.out.println("Corred!Corred!Corred!");
	System.out.println("JAAAAAA!");
	System.out.println("Insensatos!");
	
	}

}