
public class TrobarMaxMin1 {
	
	    
	    public static void main(String[]args){
	        
	        int []vector={12,3,45,-3,65,-5,88,99,2,23,54,33,27,53,96,0};
	        int mayor=vector[0];
	        int menor=vector[0];
	        
	        for(int i=1;i<vector.length;i++){
	            
	            if(vector[i]>mayor){
	                
	                mayor=vector[i];
	                
	            }else if(vector[i]<menor){
	                
	                menor=vector[i];
	                
	            }
	             
	        }
	     System.out.print("El nombre major es: "+mayor+"\nEl nombre menor es: "+menor);
	    }
	    
	}
