import java.util.Random;
	import java.util.Arrays;
	
	public class CercaValors {
		
		private int[]array=new int[10];
		
		
	    public static void main(String[] args) {
	        CercaValors programa = new CercaValors()  ;
	        programa.valorsTotal();
	        programa.Cerca();
	    }
	    
	    
	    
	    public void valorsTotal() {
	        Random rd = new Random();	        
	        System.out.print("L'array principal es= [");
	        for (int i = 0; i < array.length; i++) {
	            array[i] = rd.nextInt(11);
	            System.out.print(array[i]+", ");
	        }
	        System.out.print("]\n");		        	        
	    }
	    
	
	        
	   public int[] valorsAcercar(){
	    	
	    	 int copia1[] = Arrays.copyOfRange(array, 0, 5);
		       
		        for (int i = 0; i < copia1.length; i++) {		            
		        }		     
		        System.out.print("Valors a cercar: [ ");
		        for (int i = 0; i < copia1.length; i++) {
		            System.out.print(copia1[i]+" ");
		        }
		        System.out.println("]");
		        return copia1;
	    }
	
	   
	   public int[] valorsONcercar() {
		   
		   
		   int copia2[] = Arrays.copyOfRange(array, 5, array.length);
	        Arrays.sort(copia2);
	        System.out.print("Array on es cerca: [ ");
	        for (int i = 0; i < copia2.length; i++) {
	            System.out.print(copia2[i]+" ");
	        }
	        System.out.println("]");
	        return copia2;
	   }
	   
	   
	   public void Cerca() {
		   	
		   int copiaU[]=valorsAcercar();
		   int copiaDos[]=valorsONcercar();
		   
	        for (int i = 0; i < copiaU.length; i++) {
	            boolean trobat = false;
	            for (int j = 0; j < copiaDos.length; j++) {
	                if (copiaU[i] == copiaDos[j] && trobat == false) {
	                    System.out.println("A la posicio " + Arrays.binarySearch(copiaDos, copiaU[i]) + " hi ha el valor " + copiaU[i]);
	                    trobat = true;
	                }
	            }	        		   
	        }	   
	   }
	}			    

