public class TrobarMaxMin{
    
    public static void main(String[]args){
        
        int []vector={12,3,45,-3,65,-5,88,99,2,23,54,33,27,53,96,0};
        int major=vector[0];
        
        for(int i=0; i<vector.length-1;i++){            
        	
             for(int j=i+1;j<vector.length;j++){
            
                if(vector[j]<vector[i]){
                
                int aux=vector[j];
                vector[j]=vector[i];
                vector[i]=aux; 
                }                             
             }               
        }
        
        System.out.print("El nombre mes petit del vector es "+vector[0]+"\nEl nombre mes gran del vector es "+vector[vector.length-1]);                       
    }
    
}