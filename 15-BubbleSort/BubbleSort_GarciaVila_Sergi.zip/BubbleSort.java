
public class BubbleSort {
  public static void main (String[] args) {
    float[] llistaNotes = {5.5f, 9f, 2f, 10f, 4.9f};
    float suma=0;
    int numSusp=0;
        
    for (int i = 0; i < llistaNotes.length - 1; i++) { //El array tiene 5 posiciones, este "for" recorrerá de la 1ª a la 4ª, 

      for(int j = i + 1; j < llistaNotes.length; j++) {	//Este for recorrerá desde la 2ªposición hasta el final

        if (llistaNotes[i] > llistaNotes[j]) {  //Compara el valor de la posición  con el de la siguiente posicion si el primero es mayor :

          float aux = llistaNotes[i]; // de 2ª pos a 3ª se cumple 2º>3º, lo guarda en una variable que llamaremos "aux",entonces aux valdra 
          llistaNotes[i] = llistaNotes[j]; //9f --> Igualamos el valor de la posición 3ª al valor de la 2ª por lo que las 2 pasan a ser 2f 
          llistaNotes[j] = aux; //ahora igualamos la posición 3ª a "aux" por lo que la posición 3ª pasa a ser 9f, habremos pasado el mayor 
        }                       //a la siguiente posición. Con los for se hará: se compara paura la posición 1ª con todos los demás, luego
      }							//la 2ª con todos los demás y se van situando los mayores al final ordenados. 
    }
    
    for (int i=0;i<llistaNotes.length;i++){   //se pasa por todo el array buscando un menor de 5. En este caso como ya están ordenados 
        
        if(llistaNotes[i]<5){					//encontrará antes los suspensos?¿ , guardamos y vamos sumando los suspensos en la variable
            									//suma y vamos contando en la variable numSusp el nº de suspensos para al final hacer la media.
           suma=suma+llistaNotes[i];
           numSusp++;   
            
        }else{
            
            break;	//Este break es el que hace valer el orden del array , ya que cuando encuentre uno que no esté suspenso sale del loop, 
        }			//Haciendo que recorra unicamente las posiciones necesarias. 
    }
      float mitja=suma/numSusp;
      System.out.println("La nota mitja dels suspensos es: "+mitja);
    }
}