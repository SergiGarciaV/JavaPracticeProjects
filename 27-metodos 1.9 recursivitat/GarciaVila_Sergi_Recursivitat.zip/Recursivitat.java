public class Recursivitat {
	
	public static void main(String[]args) {
		
		Recursivitat recursius=new Recursivitat();
		
		recursius.imprimir(33);		
	}

	public void imprimir(int x) {

		if(x%2==0) {
			System.out.println("El nombre "+x+" es parell");
		}else {
			System.out.println("El nombre "+x+" es senar");
		}
		
		if(x==0) {
			System.out.print("Fi del programa");
			return;
		}
		x--;
		imprimir(x);
	}
}