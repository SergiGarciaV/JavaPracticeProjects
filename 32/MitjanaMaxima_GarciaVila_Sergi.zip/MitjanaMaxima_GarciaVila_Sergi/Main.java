import java.util.Scanner;

public class Main {

Scanner sc=new Scanner(System.in);
ArrayFactory array=new ArrayFactory();
CalcMitjaArray mitja=new CalcMitjaArray();

double mitjanaA=0;
double mitjanaB=0;
	
	public static void main(String[]args) {
		
		Main programa=new Main();
		programa.inici();
		programa.array1Create();
		programa.array2Create();
		programa.compareArrays();		
	}
	public void inici() {
		
		System.out.println("Benvingud@ al programa comparador d'arrays.\nA continuacio haura d'indicar cadascun dels parametres"
				+ "indicats per a poder crear els arrays\n");		
	}	
	
	public void array1Create() {
		
		System.out.println("\n------------------------------A R R A Y 1--------------------------------"
				+ "\n\nIntrodueixi el nombre de valors que voldra introduir a l'array 1: ");
		array.arrayLength();
		array1Lect(array.arrayVal());
	}	
	
	public void array1Lect(double[]array1) {
		
		
		System.out.print("L'array creat es = [");
		for(int i=0;i<array1.length;i++) {
			System.out.print((array1[i])+",");
		}
		System.out.print("]");	
		
		mitjanaA=mitja.arrayMitj(array1);
		System.out.print("\nLa mitjana del primer array es= "+mitjanaA);
	}
	
	public void array2Create() {
		
		System.out.println("\n\n------------------------------A R R A Y 2--------------------------------"
				+ "\n\nIntrodueixi el nombre de valors que voldra introduir a l'array 2: ");
		array.arrayLength();
		array2Lect(array.arrayVal());
	}	
	
	public void array2Lect(double[]array2) {
		
		
		System.out.print("L'array creat es = [");
		for(int i=0;i<array2.length;i++) {
			System.out.print((array2[i])+",");
		}
		System.out.print("]");	
		
		mitjanaB=mitja.arrayMitj(array2);
		System.out.print("\nLa mitjana del segon array es= "+mitjanaB);
	}
	
	public void compareArrays() {
			
		if (mitjanaA>mitjanaB) {
			System.out.print("\n\nEl PRIMER array te la mitjana mes alta.");
			
		}else if(mitjanaB>mitjanaA) {
			System.out.print("\n\nEl SEGON array te la mitjana mes alta.");
			
		}else {
			System.out.print("\n\nEls dos arrays tenen les mitjanes equivalents.");
		}	
	}		
}