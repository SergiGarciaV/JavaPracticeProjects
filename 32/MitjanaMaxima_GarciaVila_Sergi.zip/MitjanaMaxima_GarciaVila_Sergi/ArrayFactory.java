import java.util.Scanner;
public class ArrayFactory{

    Scanner sc=new Scanner(System.in);
    int mida=0;
	
	public void arrayLength() {
		
	    mida=sc.nextInt();
	
	}		
	
	public double [] arrayVal(){
	    
	        double [] array=new double[mida];
	    	for (int i=0;i<array.length;i++) {
			System.out.print("\nIntrodueixi el valor numero "+(i+1)+" :");
			double valor=sc.nextDouble();
			
			array[i]=valor;
		}
		
		return array;
	}
	
}