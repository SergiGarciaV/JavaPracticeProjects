public class CalcMitjaArray{
    
    
    public double arrayMitj(double[]array){
        
        double sum=0;
        
        for(int i=0;i<array.length;i++) {
        	
        	sum=sum+array[i];
        }
        double mitja=sum/array.length;
                     
        return mitja;
    }    
}