import java.util.Scanner;

public class eliminarValor {
	    
	    private Scanner teclat;
	    private int vecLength=0;
	    
	    
	    public static void main(String[]args){
	        
	        eliminarValor elim_especif=new eliminarValor();
	        elim_especif.introArrayLength();
	        elim_especif.valElimExe();
	    }
	    
	    public void introArrayLength(){
	        
	        teclat=new Scanner(System.in);
	        System.out.println("Introdueixi el nombre de valors que voldrà introduïr a l'array: ");
	        vecLength=teclat.nextInt();
	        }
	       
	    
	    public int[] valorsIni(){
	        
	        int arrayIni[]=new int [vecLength];
	        
	        System.out.println("A continuacio hauras d'introduir els diferents valors per a l'array, NO repeteixis valors.");
	        
	        for(int j=0;j<arrayIni.length;j++){
	            
	            System.out.print("Introdueixi el valor nº "+(j+1)+" =");
	            arrayIni[j]=teclat.nextInt();
	        }
	        
	        System.out.print("L'array creat es: [");
	        
	        for(int t=0;t<arrayIni.length;t++){
	            
	            System.out.print(" "+arrayIni[t]+" ,");
	        }
	        
	        System.out.print("]");
	        
	        return arrayIni;
	    }
	    
	    
	    public int valElimLec(){
	        
	        System.out.println("Introdueixi quin valor vol eliminar: ");
	        int valDelete=teclat.nextInt();
	      
	        return valDelete;
	    }
	    
	    
	    public void valElimExe(){	        
	      
	      int arrayIni1[]=valorsIni();
	      int valDelete1=valElimLec();
	      int arrayFin[]=new int[arrayIni1.length-1];
	      int cont=0;
	      
	      for(int i=0;i<arrayIni1.length-1;i++){
	            
	            if(arrayIni1[i]!=valDelete1) {	            	
	   
	            	cont++;	  
	            	arrayFin[i]=arrayIni1[i];
	            	
	            }else{
	            	
	            	int	aux=(arrayIni1.length-cont);	            	
	            	
	            	for(int j=cont;j<aux-1;j++) {
	           
	            		arrayIni1[j]=arrayIni1[j+1];
	            		arrayFin[j]=arrayIni1[j];
	            		
	            	}
	            }
	        }
	      System.out.print("L'array amb el valor eliminat queda aixi: [");
	      
	      for(int t=0;t<arrayFin.length;t++){
	          
	         
	          
	    	  System.out.print(" "+arrayFin[t]+" ,");
	        }
	      System.out.print("]");
	    }

}
