/**
 * 
 */
/**
 * @author sergi
 *
 */
module Figura {
}