package UF4.ProjecteFigura;

public class Quadrat extends Figura{

	private int costat;
	
	public Quadrat() {
	}
	
	public Quadrat(int c){
		
		setCostat(c);
		
	}
	
	public double calcularArea() {
		
		
		
		double area=getCostat()*getCostat();
		return area;
		
	}

	public int getCostat() {
		return costat;
	}

	public void setCostat(int Costat) {
		costat = Costat;
	}
	
	
	
}
