package UF4.ProjecteFigura;

public class Trapezi extends Figura{

	
	private int a;
	private int b;
	private int h;
	
	
	public Trapezi() {
	}
	
	public Trapezi(int a, int b, int h) {
		
		setA(a);
		setB(b);
		setH(h);	
		}
	
	
	public  double calcularArea() {
		
		
		double area=(getA()+getB())*getH()/2;
		
		return area;
		
	}


	public int getA() {
		return a;
	}


	public void setA(int a_) {
		a = a_;
	}


	public int getB() {
		return b;
	}


	public void setB(int b_) {
		b = b_;
	}


	public int getH() {
		return h;
	}


	public void setH(int h_) {
		h = h_;
	}
	
	
	
	
	
}
