package UF4.ProjecteFigura;

public class Parallelogram extends Figura{

	private int b;
	private int h;
	
	public Parallelogram() {
		
	}
	

	
	public Parallelogram(int b, int h) {
		
		setB(b);
		setH(h);
	}
	
	
	public double calcularArea() {
		
		
		
		double area=getB()*getH();
		return area;
		
	}


	public int getB() {
		return b;
	}


	public void setB(int B) {
		b = B;
	}


	public int getH() {
		return h;
	}


	public void setH(int H) {
		h = H;
	}
	
	
	
	
	
	
	
}
