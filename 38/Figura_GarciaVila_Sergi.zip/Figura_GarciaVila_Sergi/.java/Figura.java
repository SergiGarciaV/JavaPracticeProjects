package UF4.ProjecteFigura;

import java.util.Scanner;
import java.util.ArrayList;

public class Figura{

	private Scanner sc=new Scanner(System.in);
	private String fig;
	private int id;
	private double area;
	private char elec;
	private static ArrayList<Figura> LlistaFigures=new ArrayList<Figura>(); 
	
	public static void main(String[]args) {
		
		
		Figura programa=new Figura();
		
		programa.inici();
		programa.eleccio();
		programa.seguentFigura();
		programa.crearFigura();
		programa.validarFigura();
		programa.opcioFi();						
	}

	
	public void reinici() {
		
		eleccio();
		seguentFigura();	
		crearFigura();
		validarFigura();
		opcioFi();
	}
	
	public Figura() {
		
	}
	
	public void inici() {
		
		System.out.println("Benvinguda a la fabrica de figures amb càlcul d'àrees:\n");
	}
	
	public void eleccio() {
		
		System.out.println("Introdueixi el caràcter per a la figura que vulgui crear i premi 'intro', per a sortir del programa premi Z:\n\nA = Cercle\nB = Parallelogram\nC = Quadrat\nD = Rectangle\nE = Rombe\nF = Trapezi\nG = Triangle ");
		elec=sc.next().charAt(0);
	}
		
	public void seguentFigura() { //En comptes de donar el valor a la variable directament (ex: fig="cercle") ho passo al setFig() per si de cas
								  //en futures implementacions al programa, donguessim l'opció de cambiar el tipus d'alguna figura enmagatzemada, que s'hagués entrat un tipus per error...
	    switch (Character.toUpperCase(elec)) { 
        case 'Z':
            System.out.print("Fins la pròxima!");
            System.exit(1);     
        case 'A':
        	setFig("Cercle");
        	calcularAreaCercle();
        	break;
        case 'B':
        	setFig("Parallelogram");
        	calcularAreaParallelogram();
        	break;
        case 'C':
        	setFig("Quadrat");
        	calcularAreaQuadrat();
        	break;
        case 'D':
        	setFig("Rectangle");
        	calcularAreaRectangle();
        	break;
        case 'E':
        	setFig("Rombe");
        	calcularAreaRombe();
        	break;
        case 'F':
        	setFig("Trapezi");
        	calcularAreaTrapezi();
        	break;
        case 'G':
        	setFig("Triangle");
        	calcularAreaTriangle();
        	break;
        default:
            System.out.print("No has introduit un valor correcte, torna-hi:\n");
            reinici();
	    }				
	}
	

		private void calcularAreaCercle() {
		    int aux1=0;
		    
		    while(true) {
		        System.out.println("Introdueix el valor del radi del cercle:");
		    
		        if (sc.hasNextInt()) {
		            aux1=sc.nextInt();
		            break;
		        } else {
		            System.out.println("valor erroni, torna-ho a provar:");
		            sc.next();
		        }
		    }
		    
		    Cercle c=new Cercle(aux1);
		    setArea(c.calcularArea()); 
		}

		
		private void calcularAreaParallelogram() {
			
			int aux1=0;
			int aux2=0;
			
			while(true) {
				System.out.println("Introdueix el valor de la base del parallelogram:");
				if (sc.hasNextInt()) {
		            aux1=sc.nextInt();
		            break;
		        } else {
		            System.out.println("valor erroni, torna-ho a provar:");
		            sc.next();
		        }
			}
			
			while(true) {
				System.out.println("Introdueix el valor de l'alçada del parallelogram:");
				if (sc.hasNextInt()) {
		            aux2=sc.nextInt();
		            break;
		        } else {
		            System.out.println("valor erroni, torna-ho a provar:");
		            sc.next();
		        }								  
		    }
			 Parallelogram p=new Parallelogram(aux1,aux2);			
			 setArea(p.calcularArea());						
		}
		  
		  		    		   		

		private void calcularAreaQuadrat() {
			
			int aux1=0;
			
			while(true) {
				  System.out.println("Introdueix el valor del costat del quadrat:");
				if (sc.hasNextInt()) {
		            aux1=sc.nextInt();
		            break;
		        } else {
		            System.out.println("valor erroni, torna-ho a provar:");
		            sc.next();
		        }					    
		    Quadrat q=new Quadrat(aux1);		    
		    setArea(q.calcularArea());
			}
		}
		
		
		
		private void calcularAreaRectangle() {
			
			int aux1=0;
			int aux2=0;
			
			while(true) {
				System.out.println("Introdueix el valor del costat1 del rectangle:");
				if (sc.hasNextInt()) {
		            aux1=sc.nextInt();
		            break;
		        } else {
		            System.out.println("valor erroni, torna-ho a provar:");
		            sc.next();
		        }
			}
			while(true) {
				System.out.println("Introdueix el valor del costat2 del rectangle:");
				if (sc.hasNextInt()) {
			        aux2=sc.nextInt();
			        break;
			    } else {
			        System.out.println("valor erroni, torna-ho a provar:");
			        sc.next();
			      }
			}						    
		    Rectangle r=new Rectangle(aux1,aux2);		    
		    setArea(r.calcularArea());
		}
		
		
		

		private void calcularAreaRombe() {
			
			int aux1=0;
			int aux2=0;
			
			while(true) {
				System.out.println("Introdueix el valor de la diagonal major del rombe:");
				if (sc.hasNextInt()) {
		            aux1=sc.nextInt();
		            break;
		        } else {
		            System.out.println("valor erroni, torna-ho a provar:");
		            sc.next();
		        }
			}
			while(true) {
				System.out.println("Introdueix el valor de la diagonal menor del rombe:");
				if (sc.hasNextInt()) {
			        aux2=sc.nextInt();
			        break;
			    } else {
			        System.out.println("valor erroni, torna-ho a provar:");
			        sc.next();
			      }
			}					    		  
		    Rombe ro=new Rombe(aux1,aux2);		   
		    setArea(ro.calcularArea());
		}

		
		
		private void calcularAreaTrapezi() {
			
			int aux1=0;
			int aux2=0;
			int aux3=0;
			
			while(true) {
				System.out.println("Introdueix el valor de la base major del trapeci:");
				if (sc.hasNextInt()) {
		            aux1=sc.nextInt();
		            break;
		        } else {
		            System.out.println("valor erroni, torna-ho a provar:");
		            sc.next();
		        }
			}
			
			while(true) {
				System.out.println("Introdueixi el valor de la base menor del trapeci:");
				if (sc.hasNextInt()) {
			        aux2=sc.nextInt();
			        break;
			    } else {
			        System.out.println("valor erroni, torna-ho a provar:");
			        sc.next();
			      }
			}
			
			while(true) {	
				System.out.println("Introdueix el valor de l'alçada del trapeci:");
				if (sc.hasNextInt()) {
			        aux3=sc.nextInt();
			        break;
			    } else {
			        System.out.println("valor erroni, torna-ho a provar:");
			        sc.next();
			      }
			}					
	        Trapezi t=new Trapezi(aux1,aux2,aux3);	    
		    setArea(t.calcularArea());
		}
		
		
		
		private void calcularAreaTriangle() {
			
			int aux1=0;
			int aux2=0;
			
			while(true) {
				System.out.println("Introdueix el valor de la base del triangle:");
				if (sc.hasNextInt()) {
		            aux1=sc.nextInt();
		            break;
		        } else {
		            System.out.println("valor erroni, torna-ho a provar:");
		            sc.next();
		        }
			}
				
			while(true) {
				System.out.println("Introdueix el valor de l'alçada del triangle:");
				if (sc.hasNextInt()) {
			        aux2=sc.nextInt();
			        break;
			    } else {
			        System.out.println("valor erroni, torna-ho a provar:");
			        sc.next();
			      }
			}																				
			Triangle tr=new Triangle(aux1,aux2);			
			setArea(tr.calcularArea());
		}
		
		
		
	public void crearFigura() {
		
		 Figura figura=new Figura();
		 	figura.setId(id++);
		 	figura.id=getId();
			figura.fig=getFig();
			figura.area=getArea();
     	LlistaFigures.add(figura);
     	
	}
	
	
	public void validarFigura() {
		
		
     	System.out.print("\nS'ha creat amb exit el "+fig+" amb les seguents dades:\nid = "+id+"\nTipus de figura = "+fig+"\nArea = "+area);
		
		
		
	}
	
	
	public void opcioFi() {
		
		
		System.out.println("\n\n--> Prem 1 + INTRO per a registrar una altre figura\n\n--> Prem 2 per a veure per pantalla un llistat amb totes les figures creades \n\n--> Prem 3 + INTRO per a esborrar la figura que acabes de crear, en cas que t'hagis equivocat en alguna dada.\n\n--> Prem -1 + INTRO per a sortir del programa.");
		int aux=sc.nextInt();
		
		if (aux==1) {
			reinici();
		}else if(aux==-1) {
			System.out.print("Fins la pròxima!");
            System.exit(1);
		}else if(aux==2) {
			llegirDades();
		}else if(aux==3) {
			eliminarFigura(LlistaFigures.get(LlistaFigures.size()-1));
		}else if(sc.hasNextInt()==false){
			
			System.out.println("Has introduit un caràcter incorrecte per teclat, torna-ho a provar:\n");
		
		}
		
	}
	
	public void eliminarFigura(Figura figura) {
		
		LlistaFigures.remove(figura);
		System.out.print("S'ha eliminat correctament l'última figura creada.");
		
		opcioFi();
	}

	
	public String getFig() {
		return fig;
	}


	public void setFig(String fig) {
		this.fig = fig;
	}


	public double getArea() {
		return area;
	}


	public void setArea(double area) {
		this.area = area;
	}


	public int getId() {
		
		return id;
	}
	
	public void setId(int id) {
		this.id =id;
	}
	
	
	public double calcularArea(double area) {
		
		
		area=0;
		
		return area;
		
	}
		
	public void llegirDades() {
		System.out.print("\n      L L I S T A   F I G U R E S");
		for(Figura figura:LlistaFigures) {
		System.out.println("\n- - - - - - - - - - - - - - - - - - - - - ");
		System.out.println("\nLa figura amb id= "+figura.getId()+" es un "+figura.getFig()+"\nL'àrea del "+figura.getFig()+" és ="+figura.getArea()+"\n");
		
		}
		System.out.print("- - - - - - - - - - - - - - - - - - - - - ");
		
		System.out.println("\n\n--> Hi ha un total de "+LlistaFigures.size()+" figures creades!\n\n");
		opcioFi();
	}	
}
