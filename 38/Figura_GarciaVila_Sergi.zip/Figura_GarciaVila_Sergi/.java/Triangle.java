package UF4.ProjecteFigura;

public class Triangle extends Figura {

	private int base;
	private int h;
	
	
	public Triangle() {
	}
	
	public Triangle(int b, int a) {
		
		setBase(b);
		setH(a);
		
	}
	
	public double calcularArea() {
	
		
	double area=(getBase()*getH())/2;
	
	return area;
	}

	public int getBase() {
		return base;
	}

	public void setBase(int basE) {
		base = basE;
	}

	public int getH() {
		return h;
	}

	public void setH(int H) {
		h = H;
	}
	
	
	
}
