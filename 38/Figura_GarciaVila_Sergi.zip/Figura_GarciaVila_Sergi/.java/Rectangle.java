package UF4.ProjecteFigura;

public class Rectangle extends Figura{

	private int costat1;
	private int costat2;
	
	
	
	public Rectangle() {				
	}
	
	public Rectangle(int c1, int c2) {
		
		setCostat1(c1);
		setCostat2(c2);
	}
	
	
	public double calcularArea() {
		
		double area=getCostat1()*getCostat2();
		
		return area;
		
	}


	public int getCostat1() {
		return costat1;
	}


	public void setCostat1(int costat_1) {
		costat1 = costat_1;
	}


	public int getCostat2() {
		return costat2;
	}


	public void setCostat2(int costat_2) {
		costat2 = costat_2;
	}
	
	
	
	
	
}
