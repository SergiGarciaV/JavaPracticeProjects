package UF4.ProjecteFigura;


public class Cercle extends Figura{

	private int radi;
	
	public Cercle() {
		
	}
	
	public Cercle(int r) {

		setRadi(r);
	}
	
	
	public double calcularArea() {
		
		double area=Math.PI*(getRadi()*getRadi());
		
		return area;
		
	}

	public int getRadi() {
		return radi;
	}

	public void setRadi(int Radi) {
		radi = Radi;
	}
	
	
	
	
	
	
	
}
