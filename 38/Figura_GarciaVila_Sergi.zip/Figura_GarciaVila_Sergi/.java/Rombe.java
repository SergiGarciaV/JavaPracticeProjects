package UF4.ProjecteFigura;

public class Rombe extends Figura{

	
	private int dM;
	private int dm;
	
	
	public Rombe() {
	}
	
	
	public Rombe(int dM, int dm) {
		
		setdM(dM);
		setDm(dm);
		
	}
	
	
	
	public double calcularArea() {
		
		double area=getdM()*getDm()/2;
		
		return area;
		
	}



	public int getdM() {
		return dM;
	}



	public void setdM(int d_M) {
		dM = d_M;
	}



	public int getDm() {
		return dm;
	}



	public void setDm(int d_m) {
		dm = d_m;
	}
	
	
	
	
	
}
